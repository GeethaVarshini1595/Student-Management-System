import React, { useEffect, useState } from "react";
import axios from "axios";
import StudentForm from "./components/StudentForm";
import StudentList from "./components/StudentList";

function App() {
  const [students, setStudents] = useState([]);

  const fetchStudents = async () => {
    const res = await axios.get("http://localhost:5000/students");
    setStudents(res.data);
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  const deleteStudent = async (id) => {
    if (window.confirm("Delete this student?")) {
      await axios.delete(`http://localhost:5000/students/${id}`);
      fetchStudents();
    }
  };

  return (
    <div className="container mt-4">

      <div className="bg-primary text-white p-4 rounded shadow">
        <h1 className="text-center">
          🎓 Student Management System
        </h1>
      </div>

      <div className="row mt-4">

        <div className="col-md-4">
          <StudentForm fetchStudents={fetchStudents} />
        </div>

        <div className="col-md-8">
          <div className="card shadow">
            <div className="card-body">
              <h4>Total Students: {students.length}</h4>
            </div>
          </div>

          <StudentList
            students={students}
            deleteStudent={deleteStudent}
          />
        </div>

      </div>

    </div>
  );
}

export default App;