import React, { useState } from "react";
import axios from "axios";

function StudentForm({ fetchStudents }) {

  const [student, setStudent] = useState({
    name: "",
    email: "",
    course: ""
  });

  const handleChange = (e) => {
    setStudent({
      ...student,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    await axios.post(
      "http://localhost:5000/students",
      student
    );

    fetchStudents();

    setStudent({
      name: "",
      email: "",
      course: ""
    });
  };

  return (
    <div className="card shadow">
      <div className="card-body">

        <h3>Add Student</h3>

        <form onSubmit={handleSubmit}>

          <input
            className="form-control mb-3"
            placeholder="Student Name"
            name="name"
            value={student.name}
            onChange={handleChange}
          />

          <input
            className="form-control mb-3"
            placeholder="Email"
            name="email"
            value={student.email}
            onChange={handleChange}
          />

          <input
            className="form-control mb-3"
            placeholder="Course"
            name="course"
            value={student.course}
            onChange={handleChange}
          />

          <button
            className="btn btn-success w-100"
          >
            Add Student
          </button>

        </form>

      </div>
    </div>
  );
}

export default StudentForm;