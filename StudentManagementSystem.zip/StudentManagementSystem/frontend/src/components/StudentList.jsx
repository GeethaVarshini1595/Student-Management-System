function StudentList({ students, deleteStudent }) {

  return (
    <div className="row mt-3">

      {students.map((student) => (

        <div
          className="col-md-6 mb-3"
          key={student._id}
        >

          <div className="card shadow">

            <div className="card-body">

              <h5>{student.name}</h5>

              <p>📧 {student.email}</p>

              <p>📚 {student.course}</p>

              <button
                className="btn btn-danger"
                onClick={() =>
                  deleteStudent(student._id)
                }
              >
                Delete
              </button>

            </div>

          </div>

        </div>

      ))}

    </div>
  );
}

export default StudentList;